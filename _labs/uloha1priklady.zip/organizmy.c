/*
Meno:
Datum:

Simulujte nasledujucu situaciu. Organizmy su typu A,B a C a kazdy rastie nejaky cas (v simulacii 1, 2 a 3s) a potom sa rozmnozi; a potom zase dokola (nezanika). Na rozmnozenie su potrebne 2 organizmy a vznikaju 1 alebo 2 nove organizmy ostavajuceho typu (cize B a B splodia dva: A a C; C a B splodia jeden: A). Simulacia trva 10s a na zaciatku je z kazdeho typu vytvorene 1 A, 2 B a 3 C organizmy. Rozmnozenie netrva ziadny cas, cize uvazovat ci sa mozu rozmnozovat subezne nema zmysel.

1. Doplnte do programu premenne pocitajuce organizmy v systeme, pre kazdy typ jedno pocitadlo. Na konci simulacie vypiste pocty organizmov typu A, B a C. [2b]

2. Zabezpecte synchronizaciu tak, aby organizmus, ktory sa chce rozmnozit, pockal dalsi organizmus (ak treba); a aby potom oba organizmy vypisali, s akym typom sa rozmnozili. [6b]

3. Osetrite v programe spravne ukoncenie simulacie po uplynuti stanoveneho casu tak, aby uz ziadna cinnost (rast organizmu) nezacala. [2b]

Poznamky:
- na synchronizaciu pouzite iba mutexy+podmienene premenne; resp monitory
- nespoliehajte sa na uvedene casy, simulacia by mala fungovat aj s inymi casmi alebo s nahodne generovanymi casmi
- build (console): gcc organizmy.c -o organizmy -lpthread
*/


#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

#define CAS_A 1
#define CAS_B 2
#define CAS_C 3
#define POCET_A 1
#define POCET_B 2
#define POCET_C 3
#define CAS_SIMULACIA 10

// signal na zastavenie simulacie
int stoj = 0;

void rozmnoz(char typ) {
	
	char partner = 'X';
	printf("%c sa rozmnozoval s %c\n", typ, partner);
}
	
// organizmus A
void *organizmus_A() {
	while (!stoj) {
    	sleep(CAS_A); // rast organizmu
		rozmnoz('A'); // rozmnozenie
	}
	return NULL;
}

// organizmus B
void *organizmus_B() {
	while (!stoj) {
    	sleep(CAS_B); // rast organizmu
		rozmnoz('B'); // rozmnozenie
	}
	return NULL;
}

// organizmus C
void *organizmus_C() {
	while (!stoj) {
    	sleep(CAS_C); // rast organizmu
		rozmnoz('C'); // rozmnozenie
	}
	return NULL;
}

// main f.
int main(void) {
    int i;
    
    pthread_t organizmy[1000];
    
	int pocet = 0;
    for (i=0; i<POCET_A; i++) pthread_create(&organizmy[pocet++], NULL, &organizmus_A, NULL);
    for (i=0; i<POCET_B; i++) pthread_create(&organizmy[pocet++], NULL, &organizmus_B, NULL);
    for (i=0; i<POCET_C; i++) pthread_create(&organizmy[pocet++], NULL, &organizmus_C, NULL);

    sleep(10);
    stoj = 1;
    
    for (i=0; i<pocet; i++) pthread_join(organizmy[i], NULL);
    
    exit(EXIT_SUCCESS);
}
