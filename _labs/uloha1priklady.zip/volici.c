/*
https://goo.gl/ESYaxB

Meno:
Datum:

Simulujte nasledujucu situaciu. V obci su volby a 100 volicov ide volit do volebnej miestnosti, kde su 3 plenty a 1 volebna urna. Volic prichadza do miestnosti (v simulacii kazdu 1s) najskor kruzkuje kandidatov (v simulacii 2s) a nasledne vhadzuje hlasovaci listok do urny (v simulacii 1s). Simulacia konci ked odhlasuju vsetci volici.

1. Doplnte do programu premennu pocitajucu pocet volicov, ktori uz odvolili; hodnota nech je programom vypisovana kazdych 5s. [4b]

2. Zabezpecte synchronizaciu, tak, aby subezne mohli iba traja volici kruzkovat kandidatov za plentami a iba jeden volic vhadzovat listok do urny. [6b]

Poznamky:
- na synchronizaciu pouzite iba mutexy+podmienene premenne; resp monitory
- nespoliehajte sa na uvedene casy ci pocty, simulacia by mala fungovat aj s inymi casmi alebo s nahodne generovanymi casmi alebo poctami
- build (console): gcc volici.c -o volici -lpthread
*/

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#define POCET_VOLICOV 100
#define CAS_KRUZKUJ 2
#define CAS_VHADZUJ 1
#define CAS_VOLIC 1

// volic
void kruzkuj(void) {
    sleep(CAS_KRUZKUJ);
}

void vhadzuj(void) {
    sleep(CAS_VHADZUJ);
}

void *volic(void *ptr) {
    kruzkuj();
    vhadzuj();
    return NULL;
}

// main f.
int main(void) {
    pthread_t volici[POCET_VOLICOV];
    
    for (int i=0; i<POCET_VOLICOV; i++) { 
        pthread_create(&volici[i], NULL, &volic, NULL); 
        sleep(CAS_VOLIC); 
    }
    
    for (int i=0; i<POCET_VOLICOV; i++) pthread_join(volici[i], NULL);
    
    exit(EXIT_SUCCESS);
}
